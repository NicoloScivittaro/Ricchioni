import type { PlayerId } from '../../../shared/types';
/** La griglia parte dietro lo zero della pista: non collassare le file sulla linea al VIA. */
export const MIN_RACE_DISTANCE = -12;

/** Sei oggetti originali + sette effetti distinti; separati dalle abilità personali. */
export type ItemId = 'turbo' | 'sfera' | 'olio' | 'scudo' | 'super_turbo' | 'disturbo' | 'calamita' | 'piccione' | 'turbo_difettoso' | 'buca' | 'raffica' | 'paraurti' | 'mollone';

export interface KartState {
  playerId: PlayerId;
  characterId: string | null;
  colorHex: string;
  avatar: string;

  flight: 'DRIVE' | 'GLIDE' | 'FALL';
  glideStart: number;
  glideEnd: number;
  flightTime: number;
  flightEntryHeight: number;
  distance: number; // progresso totale non wrappato (per giri + classifica)
  lateral: number; // offset laterale dal centro pista (m)
  absHeading: number; // imbardata assoluta persistente (rad) — NON si resetta con la tangente locale
  heading: number; // derivato ogni frame: absHeading - angolo tangente pista (per rendering/telecamera)
  speed: number; // velocità lungo il percorso (unità/s)
  slipVelocity: number; // impulso laterale reale degli urti, smorzato dal grip
  collisionYawVelocity: number; // imbardata deterministica da contatto
  wallContact: boolean; // evita di ripetere la perdita d'urto mentre si striscia sullo stesso muro

  lap: number;
  lapStartTime: number; // raceTime all'inizio del giro corrente (statistica: miglior giro)
  bestLapTime: number; // secondi, Infinity finché non completa un giro
  nextCheckpoint: number;
  finished: boolean;
  finishTime: number;
  placement: number;

  offRoad: boolean;
  drifting: boolean;
  driftDir: -1 | 0 | 1;
  driftCharge: number;

  boostTimer: number;
  boostPower: number; // moltiplicatore extra di velocità durante il boost

  heldItem: ItemId | null;
  shielded: boolean;
  disturbTimer: number; // sterzo invertito temporaneo (colpito da "disturbo")
  oilTimer: number; // grip laterale ridotto, senza stun né freno longitudinale
  faultyTimer: number;
  bumperTimer: number;
  magnetTimer: number;
  magnetTarget: PlayerId | null;
  jumpHeight: number;
  jumpVelocity: number;
  stunTimer: number; // spin-out dopo un colpo
  invulnTimer: number; // breve invulnerabilità post-respawn/scudo

  offTrackTimer: number; // tempo continuo fuori pista/bloccato
  respawnTimer: number; // countdown prima del respawn effettivo
  lastValidCheckpointS: number; // posizione s dell'ultimo checkpoint valido (per respawn)

  steerVisual: number; // sterzo smussato per la rotazione visiva delle ruote anteriori (-1..1)
  wheelSpin: number; // angolo accumulato di rotolamento ruote (rad)

  // --- Sistema abilità personaggio (una gimmick unica per personaggio, non bonus statistici) ---
  abilityMeter: number; // 0..1, si riempie giocando bene: drift puliti, sorpassi, item evitati, checkpoint puliti
  abilityCharges: number; // Buttafuori/Ciro: 1 carica fissa per gara, NON si ricarica col meter
  abilityActive: boolean; // finestra generica attiva (Goblin "SO GUIDARE IO", Dottore "20 KG IN UN MESE")
  abilityTimer: number; // durata residua della finestra attiva
  lastAbilityPressAt: number; // raceTime dell'ultima pressione del tasto ABILITÀ (usato da Ciro)

  // Goblin — SO GUIDARE IO: drift ben caricati producono mini-turbo più potenti,
  // finché non sbatte o esce di pista (allora l'effetto si annulla in anticipo).
  driftBoostMultiplier: number; // 1 = normale

  // Dottore — 20 KG IN UN MESE: kart leggerissimo (accelera meglio, deriva
  // facile) ma molto più vulnerabile agli urti degli avversari.
  lightMode: boolean;
  accelMultiplier: number; // 1 = normale
  driftChargeRateMultiplier: number; // 1 = normale

  // Judoka — CARICO E SCARICO: kart-camion. Chi tocca viene spinto di lato e rallentato (speedCapMultiplier/speedCapTimer sul
  // BERSAGLIO, letti dalla fisica senza sapere "perche'"); il camion sterza peggio (steerMultiplier) e non perde velocita' negli urti.
  speedCapMultiplier: number; // 1 = normale
  speedCapTimer: number; // durata residua del rallentamento subito (se bersaglio di un camion)
  truckMode: boolean;
  steerMultiplier: number; // 1 = normale

  // Buttafuori — RIBALTATO MA NON MORTO: dopo uno schianto grave si apre una finestra in cui premere ABILITA' per tornare in pista.
  recoverWindow: number; // secondi rimasti per premere (0 = nessuna finestra)

  // Ciro — PAGO DOPO: posticipa l'effetto di un item subito; scade dopo
  // qualche secondo e la penalità viene applicata comunque ("DEBITO").
  debtPending: boolean;
  debtTimer: number;
  debtStun: number;
  debtDisturb: number;
  debtOil: number;
  debtBounce: number;
  // ...e retroattivo: subito DOPO un colpo (refundTimer) premere ABILITA' lo trasforma in debito (refundStun/Disturb = cosa annullare).
  refundTimer: number;
  refundStun: number;
  refundDisturb: number;
  refundOil: number;
  refundBounce: number;
}

export function createKartState(playerId: PlayerId, characterId: string | null, colorHex: string, avatar: string): KartState {
  return {
    playerId,
    characterId,
    colorHex,
    avatar,
    flight: 'DRIVE', glideStart: 0, glideEnd: 0, flightTime: 0, flightEntryHeight: 0,
    distance: 0,
    lateral: 0,
    absHeading: 0,
    heading: 0,
    speed: 0,
    slipVelocity: 0,
    collisionYawVelocity: 0,
    wallContact: false,
    lap: 0,
    lapStartTime: 0,
    bestLapTime: Infinity,
    nextCheckpoint: 0,
    finished: false,
    finishTime: 0,
    placement: 0,
    offRoad: false,
    drifting: false,
    driftDir: 0,
    driftCharge: 0,
    boostTimer: 0,
    boostPower: 0,
    heldItem: null,
    shielded: false,
    disturbTimer: 0,
    oilTimer: 0,
    faultyTimer: 0,
    bumperTimer: 0,
    magnetTimer: 0,
    magnetTarget: null,
    jumpHeight: 0,
    jumpVelocity: 0,
    stunTimer: 0,
    invulnTimer: 1.2,
    offTrackTimer: 0,
    respawnTimer: 0,
    lastValidCheckpointS: 0,
    steerVisual: 0,
    wheelSpin: 0,
    abilityMeter: 0,
    abilityCharges: characterId === 'ciro' || characterId === 'buttafuori' ? 1 : 0,
    abilityActive: false,
    abilityTimer: 0,
    lastAbilityPressAt: -99,
    driftBoostMultiplier: 1,
    lightMode: false,
    accelMultiplier: 1,
    driftChargeRateMultiplier: 1,
    speedCapMultiplier: 1,
    speedCapTimer: 0,
    truckMode: false,
    steerMultiplier: 1,
    recoverWindow: 0,
    debtPending: false,
    debtTimer: 0,
    debtStun: 0,
    debtDisturb: 0,
    debtOil: 0,
    debtBounce: 0,
    refundTimer: 0,
    refundStun: 0,
    refundDisturb: 0,
    refundOil: 0,
    refundBounce: 0
  };
}
