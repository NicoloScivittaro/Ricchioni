import {Color3,Color4,DirectionalLight,HemisphericLight,Mesh,MeshBuilder,Scene,SceneLoader,StandardMaterial,TransformNode,Vector3,DynamicTexture} from '@babylonjs/core';
import '@babylonjs/loaders/glTF';
import type {KartWorld} from './kartEnvironment';
import {RainbowTrack,RAINBOW_SCALE} from './rainbowTrack';

export function buildRainbowWorld(scene:Scene,track:RainbowTrack):KartWorld {
  scene.clearColor=new Color4(.025,.018,.085,1);scene.ambientColor=new Color3(.3,.32,.45);
  const sky=new HemisphericLight('rainbowSky',Vector3.Up(),scene);sky.intensity=.8;sky.groundColor=new Color3(.2,.15,.35);
  const sun=new DirectionalLight('rainbowSun',new Vector3(-.4,-1,.3),scene);sun.intensity=1.05;
  const mat=new StandardMaterial('glideGuideMaterial',scene);mat.diffuseColor=new Color3(.2,.85,1);mat.emissiveColor=new Color3(.08,.45,.7);mat.specularColor=Color3.Black();
  const parts:Mesh[]=[];
  for(const gap of track.gaps){
    for(const s of [gap.launch-9,gap.launch-5,gap.launch-1,gap.landing+2,gap.landing+6]){
      const pad=MeshBuilder.CreateBox('glidePad',{width:11,height:.035,depth:.65},scene);pad.position.copyFrom(track.worldPoint(s,0,.08));pad.rotation.y=track.tangentAngleAt(s);parts.push(pad);
    }
    for(const s of [gap.launch-14,gap.landing+9])for(const side of [-1,1]){
      const pole=MeshBuilder.CreateBox('glideBeacon',{width:.3,height:6,depth:.3},scene);pole.position.copyFrom(track.worldPoint(s,side*7.7,3));parts.push(pole);
    }
    // Air guide rings are sparse, non-colliding and never cover the landing surface.
    const count=gap.landing-gap.launch>100?5:1;
    for(let i=1;i<=count;i++){
      const s=gap.launch+(gap.landing-gap.launch)*i/(count+1);
      const ring=MeshBuilder.CreateTorus('glideGuide',{diameter:20,thickness:.14,tessellation:32},scene);
      ring.position.copyFrom(track.worldPoint(s,0,track.flightHeightAt(s)+2));ring.rotation.x=Math.PI/2;ring.rotation.y=track.tangentAngleAt(s);parts.push(ring);
    }
    const tex=new DynamicTexture('glideInstruction',{width:1024,height:256},scene,false);const c=tex.getContext() as CanvasRenderingContext2D;
    c.fillStyle='#101432';c.fillRect(0,0,1024,256);c.fillStyle='#6cfff1';c.font='bold 64px Arial';c.textAlign='center';c.fillText('PLANATA AUTOMATICA',512,90);c.fillStyle='#ffffff';c.font='40px Arial';c.fillText('STERZA • MIRA ALLA PISTA',512,170);tex.update();
    const signMat=new StandardMaterial('glideSign',scene);signMat.diffuseTexture=tex;signMat.emissiveTexture=tex;signMat.disableLighting=true;signMat.backFaceCulling=false;
    const sign=MeshBuilder.CreatePlane('glideSign',{width:13,height:3.25},scene);sign.position.copyFrom(track.worldPoint(gap.launch-24,10,5));sign.rotation.y=track.tangentAngleAt(gap.launch-24);sign.material=signMat;sign.isPickable=false;
  }
  const merged=Mesh.MergeMeshes(parts,true,true,undefined,false);if(merged){merged.material=mat;merged.isPickable=false;merged.freezeWorldMatrix();}
  return {sun,update:()=>{}};
}

/** Default LH glTF loader converts original XY/Z-up to Babylon XZ/Y-up. */
export async function importRainbow(scene:Scene,track:RainbowTrack):Promise<void>{
  const result=await SceneLoader.ImportMeshAsync('', '/assets/tracks/', 'gba_rainbow_road.glb',scene);
  if(scene.isDisposed){for(const mesh of result.meshes)mesh.dispose();return;}
  const anchor=new TransformNode('rainbowAssetAnchor',scene);anchor.scaling.set(-RAINBOW_SCALE,RAINBOW_SCALE,-RAINBOW_SCALE);anchor.position.set(-800,40,-240);
  const roots=result.meshes.filter(m=>!m.parent);for(const root of roots)root.parent=anchor;
  // Replace the large opaque star billboard with the sparse original guide rings:
  // at chase-camera height it obscures the landing platform.
  for(const mesh of result.meshes)if(mesh.material?.name.startsWith('M_StarRing'))mesh.setEnabled(false);
  const probes=Array.from({length:Math.ceil(track.totalLength/2)},(_,i)=>({s:i*2,p:track.positionAt(i*2),r:track.rightAt(i*2)}));
  for(const mesh of result.meshes){
    if(!mesh.material?.name.startsWith('Nila_1'))continue;
    // The supplied UV transform repeats 128 times and aliases at kart height.
    // Reproject only the driving surface; retain its original embedded tile artwork.
    const positions=mesh.getVerticesData('position');if(!positions)continue;
    const matrix=mesh.computeWorldMatrix(true),uv:number[]=[];
    for(let i=0;i<positions.length;i+=3){
      const p=Vector3.TransformCoordinates(new Vector3(positions[i],positions[i+1],positions[i+2]),matrix);let best=Infinity,probe=probes[0];
      for(const q of probes){const d=(q.p.x-p.x)**2+(q.p.z-p.z)**2;if(d<best){best=d;probe=q;}}
      const lateral=(p.x-probe.p.x)*probe.r.x+(p.z-probe.p.z)*probe.r.z;
      uv.push(.5+lateral/14.4,probe.s/32);
    }
    // Unwrap the finish seam separately on each disconnected road piece, so a
    // triangle never interpolates across an entire lap of repeated artwork.
    const indices=mesh.getIndices(),adj=Array.from({length:uv.length/2},()=>new Set<number>()),seen=new Set<number>(),period=track.totalLength/32;
    if(indices)for(let i=0;i<indices.length;i+=3)for(let a=0;a<3;a++){const x=indices[i+a],y=indices[i+(a+1)%3];adj[x].add(y);adj[y].add(x);}
    for(let start=0;start<adj.length;start++)if(!seen.has(start)){
      const queue=[start];seen.add(start);for(let i=0;i<queue.length;i++)for(const next of adj[queue[i]])if(!seen.has(next)){
        uv[next*2+1]+=Math.round((uv[queue[i]*2+1]-uv[next*2+1])/period)*period;seen.add(next);queue.push(next);
      }
    }
    mesh.setVerticesData('uv',uv);
    const source=mesh.material as unknown as {albedoTexture?:import('@babylonjs/core').Texture;emissiveTexture?:import('@babylonjs/core').Texture};
    const road=new StandardMaterial('rainbowRoadTiles',scene);road.diffuseColor=Color3.White();road.specularColor=new Color3(.12,.15,.2);road.emissiveColor=new Color3(.7,.7,.7);
    for(const [key,texture]of [['diffuseTexture',source.albedoTexture],['emissiveTexture',source.emissiveTexture]] as const){
      if(!texture)continue;const t=texture.clone();if(!t)continue;t.uScale=t.vScale=1;t.uOffset=t.vOffset=t.wAng=0;t.uRotationCenter=t.vRotationCenter=0;t.anisotropicFilteringLevel=4;road[key]=t;
    }
    mesh.material=road;road.backFaceCulling=false;
  }
  const converted=new Map<NonNullable<Mesh['material']>,StandardMaterial>();
  for(const mesh of result.meshes){
    const original=mesh.material;if(!original||original.getClassName()!=='PBRMaterial'||!mesh.isEnabled())continue;
    let material=converted.get(original);
    if(!material){
      const source=original as unknown as {albedoTexture?:import('@babylonjs/core').Texture;albedoColor:Color3;emissiveTexture?:import('@babylonjs/core').Texture;emissiveColor:Color3};
      material=new StandardMaterial(original.name+'_arcade',scene);material.diffuseColor=source.albedoColor.clone();material.diffuseTexture=source.albedoTexture??null;material.specularColor=new Color3(.06,.06,.08);
      material.emissiveTexture=source.emissiveTexture??null;material.emissiveColor=source.emissiveColor.clone();material.backFaceCulling=false;
      if(original.name.startsWith('M_Sfcmc_VR')){material.disableLighting=true;material.emissiveTexture=source.albedoTexture??null;material.emissiveColor=new Color3(.65,.72,.85);}
      converted.set(original,material);
    }
    mesh.material=material;
  }
  for(const mesh of result.meshes){mesh.isPickable=false;mesh.receiveShadows=mesh.material?.name==='rainbowRoadTiles'||!!mesh.material?.name.startsWith('Nila_');mesh.computeWorldMatrix(true);mesh.freezeWorldMatrix();}
  for(const material of scene.materials.filter(m=>result.meshes.some(mesh=>mesh.material===m))){material.backFaceCulling=false;material.freeze();}
}

/** One reusable pair of folded energy foils per kart, no particles or per-frame geometry. */
export class GlideWings {
  private wings:Mesh[]=[];private open=0;
  constructor(scene:Scene,parent:TransformNode,color:string){
    const mat=new StandardMaterial('glideFoil',scene);mat.diffuseColor=Color3.FromHexString(color);mat.emissiveColor=new Color3(.12,.4,.55);mat.specularColor=new Color3(.7,.9,1);mat.alpha=.9;
    for(const side of [-1,1]){
      const foil=MeshBuilder.CreateBox('glideFoilPart',{width:2.4,height:.06,depth:1.1},scene);
      const trail=MeshBuilder.CreateBox('glideTrailPart',{width:.09,height:.06,depth:3.3},scene);trail.position.set(side*1.08,0,-1.8);
      const wing=Mesh.MergeMeshes([foil,trail],true,true)!;wing.name='glideWing';wing.parent=parent;wing.position.set(side*1.8,2.1,-.5);wing.material=mat;wing.isPickable=false;wing.setEnabled(false);this.wings.push(wing);
    }
  }
  update(dt:number,gliding:boolean,steer:number):void {
    this.open+=(Number(gliding)-this.open)*Math.min(1,dt*9);
    this.wings.forEach((wing,i)=>{wing.setEnabled(this.open>.015);wing.scaling.x=Math.max(.01,this.open);wing.rotation.z=(i?1:-1)*(1-this.open)*1.3-steer*.16;});
  }
}
