import {RainbowTrack,stepRainbowKart} from './rainbowTrack';
import {buildRainbowWorld,importRainbow,GlideWings,GlideLandingGuide} from './rainbowWorld';
import {pads} from '../../input/GamepadManager';
import {bindingLabel,padFamily} from '../../input/padTypes';
import {profileFor} from '../../input/profiles';
import { MotionBots } from '../bots/MotionBots';
import {
  Engine,
  Scene,
  Vector3,
  Color4,
  Color3,
  HemisphericLight,
  DirectionalLight,
  ShadowGenerator,
  MeshBuilder,
  StandardMaterial,
  DynamicTexture,
  Mesh
} from '@babylonjs/core';
import type { PlayerId } from '../../../shared/types';
import type { MinigameContext } from '../types';
import { audio } from '../../core/AudioManager';
import { setGameIntensity } from '../../core/musicDirector';
import { buildTrack, buildTrackVisuals, buildCheckpoints, buildItemBoxes, LAPS, TrackSpline } from './track';
import { createKartState } from './raceTypes';
import type { KartState } from './raceTypes';
import { KartEntity, driftLevelOf, DRIFT_LEVEL_COLORS } from './kartEntity';
import { stepKartPhysics, DRIFT_THRESHOLDS } from './kartPhysics';
import type { KartInputSnapshot } from './kartPhysics';
import { ItemManager, itemLabel, itemDescription } from './items';
import { RaceManager } from './race';
import type { RaceHudEvent } from './race';
import { CameraManager, KartHud } from './cameraHud';
import { CharacterAbilities, abilityDescription, KART_TRUCK } from './abilities';
import type { AbilityFeedback, KartPressResult } from './abilities';
import { abilityHub } from '../../core/abilityHub';
import { runSteps } from '../../core/frameClock';
import { guardLoop, safely } from '../../core/loopGuard';
import { applyQuality, engineOptions } from '../../core/quality';
import { buildTrackGuides } from './trackGuides';
import { buildKartWorld } from './kartEnvironment';
import type { KartWorld } from './kartEnvironment';
import { registerEnvScene } from '../env/envDebug';
import { telemetry } from '../../core/telemetry';

import {buildTrackSetPieces} from './trackSetPieces';
import {stepTrackDynamics,trackSurface,trackSection} from './trackDynamics';
import { resolveKartContact } from './kartCollisions';

/** Orchestratore del minigioco 3D: una sola scena Babylon, più camere/viewport. */
export class BabylonKartGame {
  readonly ready:Promise<void>;
  private rainbow:RainbowTrack|null=null;
  private wings=new Map<PlayerId,GlideWings>();
  private landingGuides=new Map<PlayerId,GlideLandingGuide>();
  private windClock=0;
  private soloBots: MotionBots;
  private engine: Engine;
  private scene: Scene;
  private spline: TrackSpline;
  private checkpoints: number[];
  private karts = new Map<PlayerId, KartState>();
  private entities = new Map<PlayerId, KartEntity>();
  private items: ItemManager;
  private race: RaceManager;
  private cameraManager: CameraManager;
  private hud: KartHud;
  private abilities: CharacterAbilities;
  private unsubAbility: () => void = () => undefined;
  /** impatto delle abilita' (solo statistica debug): posizione all'attivazione e quando valutare le posizioni guadagnate */
  private rankWatch = new Map<PlayerId, { start: number; until: number }>();
  /** urti del camion del Judoka in questo uso, e ultimo urto per coppia (per non contare ogni frame di contatto) */
  private truckBumps = new Map<PlayerId, number>();
  private lastBumpAt = new Map<string, number>();
  private order: PlayerId[];
  private firstFinishPlayed = false;
  private resultsSent = false;
  private fxState = new Map<PlayerId, { level: number; boost: number }>();
  private disposed = false;
  private paused = false;
  private onResize = (): void => this.engine.resize();
  private world: KartWorld;
  private setPieces: {update(time:number):void};
  private trackAngleAt = (d: number): number => this.spline.tangentAngleAt(d);
  /** false finche' la schermata CONTROLLI e' visibile: countdown/gara restano fermi (vedi step()). */
  private controlsDone = false;
  /** Metriche solo-debug per il SESSION REPORT (F4): nessun effetto sul gameplay. Aggregate su tutti i giocatori. */
  private stats = { steerFrames: 0, steerSat: 0, throttleFrames: 0, brakeFrames: 0, totalFrames: 0, driftAttempts: 0, miniTurbos: 0, wallHits: 0 };

  constructor(
    private canvas: HTMLCanvasElement,
    private ctx: MinigameContext
  ) {
    this.soloBots = new MotionBots(ctx);
    this.engine = new Engine(canvas, engineOptions().antialias, engineOptions());
    this.scene = new Scene(this.engine);
    this.rainbow=ctx.kartTrackId==='arcobaleno'?new RainbowTrack():null;
    this.spline = this.rainbow??buildTrack();
    // Mondo intorno alla pista (cielo, luce, mare, i 4 settori coi landmark): kartEnvironment.ts. Bagliore solo su neon e luci.
    this.world = this.rainbow?buildRainbowWorld(this.scene,this.rainbow):buildKartWorld(this.scene, this.spline);
    const shadowGen = new ShadowGenerator(1024, this.world.sun);
    shadowGen.usePoissonSampling = true;
    shadowGen.bias = 0.002;
    // Standard directional projection encloses all casters. Reuse the identical map across viewports,
    // refresh every displayed frame (not every camera); moving karts still cast live shadows.
    const shadowMap=shadowGen.getShadowMap()!;shadowMap.refreshRate=0;
    this.scene.onBeforeRenderObservable.add(()=>shadowMap.resetRefreshCounter());
    this.scene.skipPointerMovePicking=true;
    if(!this.rainbow)buildTrackVisuals(this.scene, this.spline);
    this.setPieces=this.rainbow?{update:()=>{}}:buildTrackSetPieces(this.scene,this.spline);
    buildTrackGuides(this.scene, this.spline,this.rainbow?.checkpoints); // cartelli e frecce prima delle curve, portali dei checkpoint
    registerEnvScene(this.scene);
    this.checkpoints = this.rainbow?.checkpoints??buildCheckpoints(this.spline);
    const boxPlacements = buildItemBoxes(this.spline).filter(p=>!this.rainbow?.gapAt(p.s,18));

    this.abilities = new CharacterAbilities();
    abilityHub.begin('kart3d', ctx);
    this.items = new ItemManager(this.scene, boxPlacements, this.spline, ctx.rng, this.abilities, (pid, f) =>
      this.onAbilityFeedback(pid, f),
      (source,target,kind,hit)=>{
        if(!this.hud)return;
        const label=itemLabel(kind);
        if(!target){this.hud.flash(source,label,'#80fff0',.7);return;}
        this.hud.flash(source,hit?'COLPO A SEGNO!':'COLPO EVITATO',hit?'#ffd166':'#a9cfe3',.8);
        this.hud.flash(target,hit?label:'COLPO EVITATO',hit?'#ff9f7e':'#75e4ff',.8);
        if(hit){this.ctx.vibrate(target,45);this.cameraManager.shake(target,.08);}
      }
    );
    this.cameraManager = new CameraManager(this.scene);
    this.hud = new KartHud(this.scene, this.engine);
    this.unsubAbility = abilityHub.onStatus((id, st) => this.hud.setAbility(id, st));
    this.hud.setTrack(this.spline, this.checkpoints); // minimappa (prima di ensure(): ogni viewport ne riceve una)
    this.race = new RaceManager(this.checkpoints, this.spline.totalLength, Math.max(60, ctx.durationSec), this.trackAngleAt, (ev) => this.onRaceEvent(ev));

    this.order = ctx.players.filter((p) => !p.bot).map((p) => p.id);
    // Griglia equa: chi è in testa alla classifica parte dietro, gli ultimi davanti; a parità decide il caso
    // (prima la pole andava sempre a chi era entrato per primo in stanza). L'ordine dei viewport resta invariato.
    const gridSlot = new Map(
      [...ctx.players]
        .map((p) => ({ id: p.id, key: p.score + ctx.rng.next() * 0.9 }))
        .sort((a, b) => a.key - b.key)
        .map((e, slot) => [e.id, slot] as const)
    );
    ctx.players.forEach((p) => {
      const i = gridSlot.get(p.id) ?? 0;
      const state = createKartState(p.id, p.characterId, p.color, p.avatar);
      const col = i % 2 === 0 ? -1 : 1;
      const row = Math.floor(i / 2);
      state.lateral = col * (2.3 + row * 0.15);
      state.distance = -row * 3.6 - 1;
      state.absHeading = this.trackAngleAt(state.distance);
      this.karts.set(p.id, state);

      const entity = new KartEntity(this.scene, p.color, p.characterId);
      entity.updateVisual(state, this.spline);
      this.entities.set(p.id, entity);
      if(this.rainbow)this.wings.set(p.id,new GlideWings(this.scene,entity.root,p.color));
      for (const mesh of entity.shadowMeshes) shadowGen.addShadowCaster(mesh, false);

      const camStart = this.spline.worldPoint(state.distance, state.lateral, 3.5);
      if (!p.bot) {
        if(this.rainbow)this.landingGuides.set(p.id,new GlideLandingGuide(this.scene,1<<(20+this.order.indexOf(p.id))));
        this.cameraManager.ensure(p.id, camStart);
        this.hud.ensure(p.id, p.color);
      }
    });

    this.cameraManager.applyLayout(this.order);
    this.hud.layout(this.order);
    this.hud.setCountdown('3');

    // Schermata CONTROLLI: finche' e' su, il countdown/la gara restano fermi (vedi step()); alla fine gli input sono azzerati.
    this.ready=(this.rainbow?importRainbow(this.scene,this.rainbow):Promise.resolve()).then(()=>{
      if(this.disposed)return;
      if(ctx.showControls)void ctx.showControls().then(()=>{if(!this.disposed)this.controlsDone=true;});
      else this.controlsDone=true;
    });

    applyQuality(this.engine, this.scene); // preset LOW/MEDIUM/HIGH + risoluzione dinamica (core/quality)
    this.engine.runRenderLoop(guardLoop(() => {
      if (this.disposed) return;
      if (this.paused) return; // menu ESC del telefono/host: nessun input processato, gara ferma
      // Sotto-passi in tempo reale: timer/countdown/durata non dipendono dagli FPS (vedi core/frameClock).
      runSteps(this.engine.getDeltaTime(), (dt) => this.step(dt));
      this.world.update(performance.now());
      this.scene.render();
    }));
    window.addEventListener('resize', this.onResize);
  }

  /** Menu ESC (KartRaceScene): ferma fisica/input mentre il menu è aperto, senza smontare la scena 3D. */
  setPaused(paused: boolean): void {
    this.paused = paused;
  }

  private step(dt:number):void {
    const n=Math.max(1,Math.ceil(dt*120-1e-9));
    for(let i=0;i<n;i++)this.substep(dt/n);
    if(!this.disposed)this.present(dt);
  }

  private substep(dt: number): void {
    const kartsList = [...this.karts.values()];
    const invertModifier = this.ctx.modifier?.id === 'controlli_invertiti';
    this.abilities.setRaceTime(this.race.raceTime);

    // Schermata CONTROLLI in corso: la gara resta ferma (dt=0, countdown incluso) e il "tenuto troppo presto" del
    // telefono/gamepad non deve contare come partenza anticipata (upPressed valutato con dt reale SOLO a schermata chiusa).
    const raceDt = this.controlsDone ? dt : 0;
    const throttlePressed = this.controlsDone ? (pid: PlayerId): boolean => this.ctx.input.get(pid).pressed('up') : (): boolean => false;
    if (this.race.phase !== 'ended') {
      this.race.update(raceDt, kartsList, throttlePressed);
    }

    if (this.race.phase === 'racing') {
      this.soloBots.kart(dt, kartsList, this.spline);
      for (const [pid, state] of this.karts) {
        if (state.finished) continue;
        const pin = this.ctx.input.get(pid);
        const steer = pin.axis('steer').x;
        const snapshot: KartInputSnapshot = {
          left: pin.pressed('left'),
          right: pin.pressed('right'),
          up: pin.pressed('up'),
          down: pin.pressed('down'),
          drift: pin.pressed('drift'),
          item: pin.justPressed('item'),
          steer,
          driftReleased: pin.justReleased('drift')
        };
        this.stats.totalFrames++;
        this.stats.steerFrames++;
        this.stats.steerSat += Math.abs(steer);
        if (snapshot.up) this.stats.throttleFrames++;
        if (snapshot.down) this.stats.brakeFrames++;
        if (snapshot.item && state.heldItem) {
          this.items.useItem(state, kartsList, (id) => this.race.rankOf(kartsList, id));
          if(state.flight==='GLIDE'&&state.heldItem)this.hud.flash(pid,'OGGETTO DA TERRA · CONSERVATO','#ffd166',1.1);
          audio.select();
          this.ctx.vibrate(pid, 45);
          this.sendInfoLine(pid, state);
        }
        if (pin.justPressed('ability')) {
          // premuta ma non partita: avviso privato, mai silenzio
          const res: KartPressResult = this.abilities.onAbilityPress(state, kartsList, (f) => this.onAbilityFeedback(pid, f), this.trackAngleAt);
          if (res !== 'ok') {
            const text = res === 'notready' ? 'BARRA NON PIENA' : res === 'spent' ? 'ESAURITA' : state.characterId === 'buttafuori' ? 'NIENTE DA RECUPERARE' : 'NON ORA';
            abilityHub.failed(pid, text);
          }
        }

        const wasDrifting = state.drifting;
        const wasCharge = state.driftCharge;
        const wasStunned = state.stunTimer > 0;
        const wasAwaitingRespawn = state.respawnTimer > 0;
        // Stessa condizione usata dentro stepKartPhysics per decidere se assegnare il mini-turbo (vedi releaseDrift li'):
        // un azzeramento forzato (pausa/disconnessione/contesto) non deve contare ne' qui ne' nel meter delle abilita'.
        const wasGenuineDriftEnd = snapshot.drift || snapshot.driftReleased;
        const from={distance:state.distance,lateral:state.lateral},wasAirborne=state.jumpHeight>0;
        if(this.rainbow)stepRainbowKart(state,snapshot,dt,this.rainbow,invertModifier,event=>{
          if(event==='launch'){this.sendInfoLine(pid,state);audio.kartGlide('launch');this.hud.flash(pid,'ALI APERTE · MIRA AL PORTALE','#6cfff1',1.25);this.ctx.vibrate(pid,50);}
          else if(event==='land'){this.sendInfoLine(pid,state);audio.kartGlide('land');this.hud.flash(pid,'ATTERRAGGIO!','#b4ff9e',.75);this.ctx.vibrate(pid,25);this.cameraManager.shake(pid,.045);}
          else {audio.fall();this.hud.flash(pid,'CADUTA · RIPARTI DAL CHECKPOINT','#ffb796',1.2);}
        });
        else stepKartPhysics(state, snapshot, dt, (d) => this.spline.widthAt(d) / 2, this.trackAngleAt, invertModifier,trackSurface(state.distance,state.lateral,this.spline.totalLength));
        if(!this.rainbow)stepTrackDynamics(state,from,this.spline.totalLength,d=>this.spline.widthAt(d),this.race.raceTime,event=>{
          if(event==='launch'){audio.kartBoost(9);this.ctx.vibrate(pid,30);this.hud.flash(pid,'DECOLLO!','#ffd166',.6);}
          if(event==='obstacle'){audio.hit();this.cameraManager.shake(pid,.14);this.ctx.vibrate(pid,50);}
        });
        if(!this.rainbow && wasAirborne && state.jumpHeight===0){audio.thump(.45);this.cameraManager.shake(pid,.08);this.ctx.vibrate(pid,22);}

        const wallCrashed = !wasStunned && state.stunTimer > 0;
        const respawnTriggered = !wasAwaitingRespawn && state.respawnTimer > 0;
        this.abilities.update(dt, state, kartsList, wallCrashed, respawnTriggered, this.trackAngleAt, (f) => this.onAbilityFeedback(pid, f));
        if (wallCrashed) this.stats.wallHits++;
        if (!wasDrifting && state.drifting) this.stats.driftAttempts++;

        if (wasDrifting && !state.drifting && wasCharge >= DRIFT_THRESHOLDS[0] && wasGenuineDriftEnd) {
          // suono, vibrazione, FOV e particelle del boost partono da trackFeedback() (vale anche per item e partenza lanciata)
          this.stats.miniTurbos++;
          if (wasCharge >= DRIFT_THRESHOLDS[1]) this.abilities.addMeter(state, 0.22);
        }
        if (!wasStunned && state.stunTimer > 0) {
          audio.hit();
          this.ctx.vibrate(pid, 90);
        }
      }
      this.resolveKartCollisions();

      // items.update() può assegnare un item raccolto O infliggere un colpo
      // (proiettile/trappola/disturbo): il confronto va fatto DOPO, altrimenti
      // si vede sempre lo stato di un frame prima (il cambio avviene qui dentro).
      const prevHeldItem = new Map(kartsList.map((k) => [k.playerId, k.heldItem]));
      const prevStun = new Map(kartsList.map((k) => [k.playerId, k.stunTimer]));
      this.items.update(dt, kartsList, (pid) => this.race.rankOf(kartsList, pid), this.karts.size);
      for (const state of kartsList) {
        if (prevHeldItem.get(state.playerId) === null && state.heldItem !== null) {
          this.ctx.vibrate(state.playerId, 40);
          this.sendInfoLine(state.playerId, state);
        }
        const itemCrashed = (prevStun.get(state.playerId) ?? 0) <= 0 && state.stunTimer > 0;
        if (itemCrashed) {
          this.abilities.reactToCrash(state, true, false, this.trackAngleAt, (f) => this.onAbilityFeedback(state.playerId, f));
        }
      }
    }


    if (this.race.phase === 'ended' && !this.resultsSent) {
      this.resultsSent = true;
      // Solo debug (SESSION REPORT, F4): nessun effetto sul gameplay. Aggregate su tutti i giocatori della gara.
      const s = this.stats;
      telemetry.metrics('kart3d', {
        steerSatPct: s.steerFrames ? Math.round((s.steerSat / s.steerFrames) * 100) : 0,
        throttlePct: s.totalFrames ? Math.round((s.throttleFrames / s.totalFrames) * 100) : 0,
        brakePct: s.totalFrames ? Math.round((s.brakeFrames / s.totalFrames) * 100) : 0,
        driftAttempts: s.driftAttempts,
        miniTurbos: s.miniTurbos,
        wallHits: s.wallHits
      });
      this.ctx.finish({ results: this.race.buildResults(kartsList) });
    }

    // Azzera gli edge (justPressed/justReleased) qui: questa scena pilota il proprio
    // render loop (Babylon), non quello di Phaser, quindi non possiamo fare
    // affidamento sull'update() della Scene Phaser per il timing corretto.
    this.ctx.input.update();
  }

  private present(dt:number):void {
    const kartsList=[...this.karts.values()];
    for (const [pid, state] of this.karts) {
      abilityHub.setStatus(pid, this.abilities.status(state)); // HUD + Companion Card (solo presentazione)
      const watch = this.rankWatch.get(pid);
      if (watch && this.race.raceTime >= watch.until) {
        this.rankWatch.delete(pid);
        abilityHub.impact(pid, 'posizioni guadagnate', watch.start - this.race.rankOf(kartsList, pid)); // durante e subito dopo l'abilita'
      }
      const throttle = this.race.phase === 'racing' && this.ctx.input.get(pid).pressed('up') ? 1 : 0;
      this.entities.get(pid)?.updateVisual(state, this.spline, throttle);
      this.wings.get(pid)?.update(dt,state.flight==='GLIDE',state.steerVisual);
      if(this.rainbow)this.landingGuides.get(pid)?.update(state,this.rainbow);
      this.trackFeedback(pid, state);
      this.cameraManager.update(dt, pid, state, this.spline);
      const slot=pads.slotOf(pid),binding=profileFor('kart3d')?.controls.find(c=>c.action==='ABILITY')?.binding;
      this.hud.setAbilityButton(pid,slot?.state==='paired'&&binding?bindingLabel(binding,padFamily(slot.padId)):'📱 ⚡');
      this.hud.update(pid, state, this.karts.size, LAPS, DRIFT_THRESHOLDS, dt);
    }
    this.hud.updateMinimap([...this.karts.values()], this.spline);
    this.hud.layout(this.order);

    this.windClock-=dt;
    if(this.rainbow&&this.windClock<=0&&this.order.some(id=>this.karts.get(id)?.flight==='GLIDE')){audio.kartGlide('wind');this.windClock=.4;}
    this.setPieces.update(this.race.raceTime);
    for(const [id,state] of this.karts)this.hud.setSector(id,this.rainbow?(state.flight==='GLIDE'?'PLANATA':state.flight==='FALL'?'RECUPERO':'STRADA ARCOBALENO'):trackSection(state.distance,this.spline.totalLength),this.race.raceTime);
  }

  /**
   * Feedback di guida generico (fronti di salita): il giocatore deve CAPIRE quando sta facendo un buon drift.
   *  - ogni livello di mini-turbo raggiunto: blip che sale di tono, vibrazione breve, scritta colorata (stesso colore di
   *    scintille, fanali e barra); scintille e fanali cambiano da soli in KartEntity
   *  - partenza di un boost (drift rilasciato, item, partenza lanciata): FOV, particelle, whoosh, colpo di giri, vibrazione
   */
  private trackFeedback(pid: PlayerId, state: KartState): void {
    const fx = this.fxState.get(pid) ?? { level: 0, boost: 0 };
    this.fxState.set(pid, fx);
    const level = state.drifting ? driftLevelOf(state.driftCharge) : 0;
    if (level > fx.level) {
      const c = DRIFT_LEVEL_COLORS[level];
      const hex = '#' + c.map((v) => Math.round(v * 255).toString(16).padStart(2, '0')).join('');
      audio.driftLevel(level);
      this.ctx.vibrate(pid, 16 + level * 6);
      this.hud.flash(pid, level === 3 ? '⚡⚡⚡ MAX!' : '⚡'.repeat(level) + ` TURBO ${level}`, hex, 0.55);
    }
    fx.level = level;
    if (state.boostTimer > 0 && fx.boost <= 0) {
      this.entities.get(pid)?.burstBoost();
      this.entities.get(pid)?.playBoost();
      this.cameraManager.kick(pid);
      audio.kartBoost(state.boostPower);
      this.ctx.vibrate(pid, 70);
    }
    fx.boost = state.boostTimer;
  }

  /** Il camion del Judoka tocca un altro kart: spinta laterale in piu' e rallentamento (visto dalla fisica come speedCap generico). */
  private truckBump(truck: KartState, other: KartState, away: number): void {
    other.lateral += away * KART_TRUCK.p.shove * 0.1;
    other.speedCapMultiplier = Math.min(other.speedCapMultiplier, KART_TRUCK.p.slow);
    other.speedCapTimer = Math.max(other.speedCapTimer, KART_TRUCK.p.slowTime);
    const key = `${truck.playerId}>${other.playerId}`;
    const last = this.lastBumpAt.get(key) ?? -99;
    if (this.race.raceTime - last > 1.2) {
      this.truckBumps.set(truck.playerId, (this.truckBumps.get(truck.playerId) ?? 0) + 1);
      abilityHub.impact(truck.playerId, 'rivali spinti');
      this.hud.flash(other.playerId, 'TI HA INVESTITO UN CAMION!', '#facc15', 0.9);
      this.entities.get(truck.playerId)?.playAbility();
    }
    this.lastBumpAt.set(key, this.race.raceTime);
  }

  private resolveKartCollisions(): void {
    const list = [...this.karts.values()].filter((k) => !k.finished && k.respawnTimer <= 0);
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const a = list[i];
        const b = list[j];
        const frame = (k: KartState) => {
          const pos = this.spline.worldPoint(k.distance, k.lateral);
          pos.y += k.jumpHeight;
          return { x: pos.x, y: pos.y, z: pos.z, trackAngle: this.trackAngleAt(k.distance) };
        };
        const aStun = a.stunTimer, bStun = b.stunTimer;
        const contact = resolveKartContact(a, b, frame(a), frame(b));
        if (!contact) continue;
        const aTruck = a.truckMode && !b.truckMode;
        const bTruck = b.truckMode && !a.truckMode;
        if (aTruck || bTruck) {
          const truck = aTruck ? a : b, other = aTruck ? b : a;
          const right = this.spline.rightAt(other.distance);
          const away = (contact.nx * right.x + contact.nz * right.z) * (aTruck ? 1 : -1);
          this.truckBump(truck, other, Math.sign(away) || 1);
        }
        for (const [kart, previousStun] of [[a, aStun], [b, bStun]] as const) {
          if (previousStun <= 0 && kart.stunTimer > 0) {
            this.abilities.reactToCrash(kart, true, false, this.trackAngleAt, f => this.onAbilityFeedback(kart.playerId, f));
          }
        }
        if (contact.closingSpeed <= .5) continue; // nessun rumble continuo per due kart affiancati alla stessa velocità
        const heavy = Math.min(1, contact.closingSpeed / 30);
        const bump = 15 + heavy * 35;
        audio.kartBump(heavy);
        this.ctx.vibrate(a.playerId, bump);
        this.ctx.vibrate(b.playerId, bump);
        if (heavy > .65) {
          this.cameraManager.shake(a.playerId, .12);
          this.cameraManager.shake(b.playerId, .12);
        }
      }
    }
  }

  /** Riga sul telefono: cosa fa l'item tenuto (se c'è) + cosa fa l'abilità del personaggio. */
  private sendInfoLine(playerId: PlayerId, state: KartState): void {
    this.ctx.sendPrivate(playerId, {
      type: 'info',
      item: state.heldItem ? `${itemLabel(state.heldItem)} — ${itemDescription(state.heldItem)}` : null,
      ability: (state.flight==='GLIDE'?'PLANATA: il cerchio indica dove atterri rilasciando lo sterzo. Verde = in linea. Gli oggetti da terra restano conservati. · ':'')+abilityDescription(state.characterId)
    });
  }

  private onAbilityFeedback(playerId: PlayerId, f: AbilityFeedback): void {
    const state = this.karts.get(playerId);
    // attivazioni (non gli esiti): posa del pilota + simbolo del personaggio sopra il kart + conteggio d'uso
    if (f.type === 'so_guidare_start' || f.type === 'dottore_light_start' || f.type === 'judoka_activate' || f.type === 'ciro_debt_start' || f.type === 'buttafuori_recovery') {
      this.entities.get(playerId)?.playAbility();
      abilityHub.activated(playerId);
      if (state) this.rankWatch.set(playerId, { start: this.race.rankOf([...this.karts.values()], playerId), until: this.race.raceTime + (state.abilityTimer || 0) + 3 });
    }
    switch (f.type) {
      case 'so_guidare_start':
        this.hud.flash(playerId, 'SO GUIDARE IO!', '#4ade80');
        audio.boost();
        this.ctx.vibrate(playerId, 100);
        break;
      case 'so_guidare_fail':
        abilityHub.wasted(playerId);
        this.hud.flash(playerId, 'EH SÌ, GUIDI BENISSIMO.', '#9ca3af');
        audio.wrong();
        this.ctx.vibrate(playerId, 60);
        break;
      case 'buttafuori_window':
        this.hud.flash(playerId, 'PREMI ABILITÀ: RIBALTATO MA NON MORTO!', '#f97316', 1.4);
        audio.select();
        this.ctx.vibrate(playerId, 60);
        break;
      case 'buttafuori_recovery':
        abilityHub.succeeded(playerId, 'recuperi');
        this.hud.flash(playerId, 'RIBALTATO MA NON MORTO!', '#f97316');
        audio.hit();
        this.ctx.vibrate(playerId, 130);
        break;
      case 'buttafuori_missed':
        abilityHub.impact(playerId, 'finestre perse');
        break;
      case 'dottore_light_start':
        this.hud.flash(playerId, '20 KG IN UN MESE!', '#22d3ee');
        audio.select();
        this.ctx.vibrate(playerId, 90);
        break;
      case 'judoka_activate':
        this.truckBumps.set(playerId, 0);
        this.hud.flash(playerId, 'CARICO E SCARICO!', '#facc15');
        audio.hit();
        this.ctx.vibrate(playerId, 90);
        break;
      case 'judoka_end':
        if ((this.truckBumps.get(playerId) ?? 0) > 0) abilityHub.succeeded(playerId, 'camion con urti');
        else abilityHub.wasted(playerId);
        break;
      case 'judoka_fail':
        abilityHub.wasted(playerId);
        this.hud.flash(playerId, 'CAMION FERMO: HAI SBATTUTO...', '#9ca3af');
        audio.wrong();
        this.ctx.vibrate(playerId, 50);
        break;
      case 'ciro_armed':
        this.hud.flash(playerId, 'PAGO DOPO… (ARMATO PER UN ATTIMO)', '#a78bfa', 0.8);
        audio.tick();
        break;
      case 'ciro_debt_start':
        abilityHub.succeeded(playerId, 'colpi rimandati');
        this.hud.flash(playerId, 'PAGO DOPO!', '#a78bfa');
        audio.select();
        this.ctx.vibrate(playerId, 70);
        break;
      case 'ciro_debt_due':
        this.hud.flash(playerId, 'DEBITO RISCOSSO!', '#f472b6', 1.6);
        audio.hit();
        this.ctx.vibrate(playerId, 110);
        break;
    }
  }

  private onRaceEvent(ev: RaceHudEvent): void {
    if (this.disposed) return;
    if (ev.type === 'countdown') {
      if (ev.value && ev.value > 0) {
        this.hud.setCountdown(String(ev.value));
        audio.countdown(ev.value); // toni crescenti comuni a tutti i giochi: 3 → 2 → 1 → VIA
        for (const pid of this.order) this.ctx.vibrate(pid, 35);
      } else {
        this.hud.setCountdown('VIA!');
        audio.go();
        for (const pid of this.order) {
          this.ctx.vibrate(pid, 110);
          const k = this.karts.get(pid);
          if (k) this.sendInfoLine(pid, k);
        }
        setTimeout(() => {
          if (!this.disposed) this.hud.setCountdown('');
        }, 700);
      }
    } else if (ev.type === 'lap') {
      audio.select();
      if ((ev.value ?? 0) === LAPS - 1) {setGameIntensity(2);if(ev.playerId)this.hud.flash(ev.playerId,'ULTIMO GIRO','#ffd166',1.6);audio.playTone(660,.12,'triangle',.06);audio.playTone(990,.22,'sine',.05);} // giro finale: strato musicale in piu'
    } else if (ev.type === 'finish') {
      if (ev.playerId) this.ctx.vibrate(ev.playerId, 160);
      if (ev.playerId) this.entities.get(ev.playerId)?.playFinish(!this.firstFinishPlayed);
      if (ev.playerId) {
        // posizione d'arrivo grande e chiara nella propria finestra
        const place = this.karts.get(ev.playerId)?.placement ?? 0;
        if (place > 0) this.hud.flash(ev.playerId, place === 1 ? '🏁 1° ARRIVATO!' : `🏁 ${place}° ARRIVATO`, place === 1 ? '#facc15' : '#ffffff', 2.4);
      }
      if (!this.firstFinishPlayed) {
        this.firstFinishPlayed = true;
        audio.kartFinish(true);
      } else {
        audio.kartFinish(false);
      }
    } else if (ev.type === 'checkpoint_clean' && ev.playerId) {
      const k = this.karts.get(ev.playerId);
      if (k) this.abilities.addMeter(k, 0.08);
      this.hud.flash(ev.playerId, '✔ CHECKPOINT', '#22d3ee', 0.6);
    } else if (ev.type === 'overtake' && ev.playerId) {
      const k = this.karts.get(ev.playerId);
      if (k) this.abilities.addMeter(k, 0.18);
    }
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.unsubAbility();
    abilityHub.end(); // statistiche del round + card spenta sui telefoni
    window.removeEventListener('resize', this.onResize);
    safely('entities', () => {
      for (const e of this.entities.values()) e.dispose();
    });
    safely('items.dispose', () => this.items.dispose());
    safely('cameraManager.dispose', () => this.cameraManager.dispose());
    safely('hud.dispose', () => this.hud.dispose());
    safely('engine.stopRenderLoop', () => this.engine.stopRenderLoop());
    safely('scene.dispose', () => this.scene.dispose());
    safely('engine.dispose', () => this.engine.dispose());
  }
}
